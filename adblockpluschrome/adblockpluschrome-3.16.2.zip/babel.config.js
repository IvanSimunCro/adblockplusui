/* global module */

"use strict";

module.exports = {
  presets: [
    "@babel/preset-env",
    "@babel/preset-typescript"
  ]
};
